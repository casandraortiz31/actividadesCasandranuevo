package com.example.app_audios;


import static androidx.core.content.ContextCompat.startActivities;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.media.MediaPlayer;
import android.widget.Toast;

public class ViewActivity extends AppCompatActivity {

    Button play1, play2, play3, play4, play5, play6, play7, play8, play9, play10, share1, share2, share3, share4, share5, share6, share7, share8, share9, share10, blue1, blue2, blue3, blue4, blue5, blue6, blue7, blue8, blue9, blue10;

    MediaPlayer mp1, mp2, mp3, mp4, mp5, mp6, mp7, mp8, mp9, mp10;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view);
        play1 = (Button) findViewById(R.id.play1);
        play2 = (Button) findViewById(R.id.play2);
        play3 = (Button) findViewById(R.id.play3);
        play4 = (Button) findViewById(R.id.play4);
        play5 = (Button) findViewById(R.id.play5);
        play6 = (Button) findViewById(R.id.play6);
        play7 = (Button) findViewById(R.id.play7);
        play8 = (Button) findViewById(R.id.play8);
        play9 = (Button) findViewById(R.id.play9);
        play10 = (Button) findViewById(R.id.play10);
        share1 = (Button) findViewById(R.id.share1);
        share2 = (Button) findViewById(R.id.share2);
        share3 = (Button) findViewById(R.id.share3);
        share4 = (Button) findViewById(R.id.share4);
        share5 = (Button) findViewById(R.id.share5);
        share6 = (Button) findViewById(R.id.share6);
        share7 = (Button) findViewById(R.id.share7);
        share8 = (Button) findViewById(R.id.share8);
        share9 = (Button) findViewById(R.id.share9);
        share10 = (Button) findViewById(R.id.share10);
        blue1 = (Button) findViewById(R.id.blue1);
        blue2 = (Button) findViewById(R.id.blue2);
        blue3 = (Button) findViewById(R.id.blue3);
        blue4 = (Button) findViewById(R.id.blue4);
        blue5 = (Button) findViewById(R.id.blue5);
        blue6 = (Button) findViewById(R.id.blue6);
        blue7 = (Button) findViewById(R.id.blue7);
        blue8 = (Button) findViewById(R.id.blue8);
        blue9 = (Button) findViewById(R.id.blue9);
        blue10 = (Button) findViewById(R.id.blue10);
        mp1 = MediaPlayer.create(this, R.raw.dragonball);
        mp2 = MediaPlayer.create(this, R.raw.freddykrugermp3);
        mp3 = MediaPlayer.create(this, R.raw.harrypotter);
        mp4 = MediaPlayer.create(this, R.raw.mujerbonita);
        mp5 = MediaPlayer.create(this, R.raw.panterarosa);
        mp6 = MediaPlayer.create(this, R.raw.piratasdelcaribe);
        mp7 = MediaPlayer.create(this, R.raw.rocky);
        mp8 = MediaPlayer.create(this, R.raw.shrek);
        mp9 = MediaPlayer.create(this, R.raw.starwars);
        mp10 = MediaPlayer.create(this, R.raw.viernesjasonmp3);


        play1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mp1.isPlaying()) {
                    mp1.pause();
                    Toast.makeText(ViewActivity.this, "Pausa", Toast.LENGTH_SHORT).show();
                } else {
                    mp1.start();
                    Toast.makeText(ViewActivity.this, "Play", Toast.LENGTH_SHORT).show();
                }
            }
        });

        play2.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (mp2.isPlaying()) {
                    mp2.pause();
                    Toast.makeText(ViewActivity.this, "Pausa", Toast.LENGTH_SHORT).show();
                } else {
                    mp2.start();
                    Toast.makeText(ViewActivity.this, "Play", Toast.LENGTH_SHORT).show();
                }
            }
        });

        play3.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (mp3.isPlaying()) {
                    mp3.pause();
                    Toast.makeText(ViewActivity.this, "Pausa", Toast.LENGTH_SHORT).show();
                } else {
                    mp3.start();
                    Toast.makeText(ViewActivity.this, "Play", Toast.LENGTH_SHORT).show();
                }
            }
        });

        play4.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (mp4.isPlaying()) {
                    mp4.pause();
                    Toast.makeText(ViewActivity.this, "Pausa", Toast.LENGTH_SHORT).show();
                } else {
                    mp4.start();
                    Toast.makeText(ViewActivity.this, "Play", Toast.LENGTH_SHORT).show();
                }
            }
        });

        play5.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (mp5.isPlaying()) {
                    mp5.pause();
                    Toast.makeText(ViewActivity.this, "Pausa", Toast.LENGTH_SHORT).show();
                } else {
                    mp5.start();
                    Toast.makeText(ViewActivity.this, "Play", Toast.LENGTH_SHORT).show();
                }
            }
        });

        play6.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (mp6.isPlaying()) {
                    mp6.pause();
                    Toast.makeText(ViewActivity.this, "Pausa", Toast.LENGTH_SHORT).show();
                } else {
                    mp6.start();
                    Toast.makeText(ViewActivity.this, "Play", Toast.LENGTH_SHORT).show();
                }
            }
        });

        play7.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (mp7.isPlaying()) {
                    mp7.pause();
                    Toast.makeText(ViewActivity.this, "Pausa", Toast.LENGTH_SHORT).show();
                } else {
                    mp7.start();
                    Toast.makeText(ViewActivity.this, "Play", Toast.LENGTH_SHORT).show();
                }
            }
        });

        play8.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (mp8.isPlaying()) {
                    mp8.pause();
                    Toast.makeText(ViewActivity.this, "Pausa", Toast.LENGTH_SHORT).show();
                } else {
                    mp8.start();
                    Toast.makeText(ViewActivity.this, "Play", Toast.LENGTH_SHORT).show();
                }
            }
        });

        play9.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (mp9.isPlaying()) {
                    mp9.pause();
                    Toast.makeText(ViewActivity.this, "Pausa", Toast.LENGTH_SHORT).show();
                } else {
                    mp9.start();
                    Toast.makeText(ViewActivity.this, "Play", Toast.LENGTH_SHORT).show();
                }
            }
        });

        play10.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (mp10.isPlaying()) {
                    mp10.pause();
                    Toast.makeText(ViewActivity.this, "Pausa", Toast.LENGTH_SHORT).show();
                } else {
                    mp10.start();
                    Toast.makeText(ViewActivity.this, "Play", Toast.LENGTH_SHORT).show();
                }
            }
        });

        share1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent i = new Intent(ViewActivity.this, Shareactivity.class);
                startActivity(i);
            }
        });

        share2.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent i = new Intent(ViewActivity.this, Shareactivity.class);
                startActivity(i);
            }
        });

        share3.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent i = new Intent(ViewActivity.this, Shareactivity.class);
                startActivity(i);
            }
        });

        share4.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent i = new Intent(ViewActivity.this, Shareactivity.class);
                startActivity(i);
            }
        });

        share5.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent i = new Intent(ViewActivity.this, Shareactivity.class);
                startActivity(i);
            }
        });

        share6.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent i = new Intent(ViewActivity.this, Shareactivity.class);
                startActivity(i);
            }
        });

        share7.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent i = new Intent(ViewActivity.this, Shareactivity.class);
                startActivity(i);
            }
        });

        share8.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent i = new Intent(ViewActivity.this, Shareactivity.class);
                startActivity(i);
            }
        });

        share9.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent i = new Intent(ViewActivity.this, Shareactivity.class);
                startActivity(i);
            }
        });

        share10.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent i = new Intent(ViewActivity.this, Shareactivity.class);
                startActivity(i);
            }
        });

        blue1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder alerta = new AlertDialog.Builder(ViewActivity.this);
                alerta.setMessage("Muchas Felicidades, has coseguido un punto, Sigue juntando puntos para recibir fantasticas recompensas....¿Deseas salir de la Aplicación?")
                        .setCancelable(false)
                        .setPositiveButton("Si", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                finish();
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();
                            }
                        });
                AlertDialog titulo = alerta.create();
                titulo.setTitle("FELICIDADES!!!");
                titulo.show();
            }
        });

        blue2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder alerta = new AlertDialog.Builder(ViewActivity.this);
                alerta.setMessage("Muchas Felicidades, has coseguido un punto, Sigue juntando puntos para recibir fantasticas recompensas....¿Deseas salir de la Aplicación?")
                        .setCancelable(false)
                        .setPositiveButton("Si", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                finish();
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();
                            }
                        });
                AlertDialog titulo = alerta.create();
                titulo.setTitle("FELICIDADES!!!");
                titulo.show();
            }
        });

        blue3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder alerta = new AlertDialog.Builder(ViewActivity.this);
                alerta.setMessage("Muchas Felicidades, has coseguido un punto, Sigue juntando puntos para recibir fantasticas recompensas....¿Deseas salir de la Aplicación?")
                        .setCancelable(false)
                        .setPositiveButton("Si", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                finish();
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();
                            }
                        });
                AlertDialog titulo = alerta.create();
                titulo.setTitle("FELICIDADES!!!");
                titulo.show();
            }
        });

        blue4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder alerta = new AlertDialog.Builder(ViewActivity.this);
                alerta.setMessage("Muchas Felicidades, has coseguido un punto, Sigue juntando puntos para recibir fantasticas recompensas....¿Deseas salir de la Aplicación?")
                        .setCancelable(false)
                        .setPositiveButton("Si", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                finish();
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();
                            }
                        });
                AlertDialog titulo = alerta.create();
                titulo.setTitle("FELICIDADES!!!");
                titulo.show();
            }
        });

        blue5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder alerta = new AlertDialog.Builder(ViewActivity.this);
                alerta.setMessage("Muchas Felicidades, has coseguido un punto, Sigue juntando puntos para recibir fantasticas recompensas....¿Deseas salir de la Aplicación?")
                        .setCancelable(false)
                        .setPositiveButton("Si", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                finish();
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();
                            }
                        });
                AlertDialog titulo = alerta.create();
                titulo.setTitle("FELICIDADES!!!");
                titulo.show();
            }
        });

        blue6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder alerta = new AlertDialog.Builder(ViewActivity.this);
                alerta.setMessage("Muchas Felicidades, has coseguido un punto, Sigue juntando puntos para recibir fantasticas recompensas....¿Deseas salir de la Aplicación?")
                        .setCancelable(false)
                        .setPositiveButton("Si", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                finish();
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();
                            }
                        });
                AlertDialog titulo = alerta.create();
                titulo.setTitle("FELICIDADES!!!");
                titulo.show();
            }
        });

        blue7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder alerta = new AlertDialog.Builder(ViewActivity.this);
                alerta.setMessage("Muchas Felicidades, has coseguido un punto, Sigue juntando puntos para recibir fantasticas recompensas....¿Deseas salir de la Aplicación?")
                        .setCancelable(false)
                        .setPositiveButton("Si", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                finish();
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();
                            }
                        });
                AlertDialog titulo = alerta.create();
                titulo.setTitle("FELICIDADES!!!");
                titulo.show();
            }
        });

        blue8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder alerta = new AlertDialog.Builder(ViewActivity.this);
                alerta.setMessage("Muchas Felicidades, has coseguido un punto, Sigue juntando puntos para recibir fantasticas recompensas....¿Deseas salir de la Aplicación?")
                        .setCancelable(false)
                        .setPositiveButton("Si", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                finish();
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();
                            }
                        });
                AlertDialog titulo = alerta.create();
                titulo.setTitle("FELICIDADES!!!");
                titulo.show();
            }
        });

        blue9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder alerta = new AlertDialog.Builder(ViewActivity.this);
                alerta.setMessage("Muchas Felicidades, has coseguido un punto, Sigue juntando puntos para recibir fantasticas recompensas....¿Deseas salir de la Aplicación?")
                        .setCancelable(false)
                        .setPositiveButton("Si", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                finish();
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();
                            }
                        });
                AlertDialog titulo = alerta.create();
                titulo.setTitle("FELICIDADES!!!");
                titulo.show();
            }
        });

        blue10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder alerta = new AlertDialog.Builder(ViewActivity.this);
                alerta.setMessage("Muchas Felicidades, has coseguido un punto, Sigue juntando puntos para recibir fantasticas recompensas....¿Deseas salir de la Aplicación?")
                        .setCancelable(false)
                        .setPositiveButton("Si", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                finish();
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();
                            }
                        });
                AlertDialog titulo = alerta.create();
                titulo.setTitle("FELICIDADES!!!");
                titulo.show();
            }
        });

    }
}












